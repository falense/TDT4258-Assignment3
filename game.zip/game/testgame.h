#ifndef testg
#define testg


void testfunc(){
	printf("sd\n");
}

#endif